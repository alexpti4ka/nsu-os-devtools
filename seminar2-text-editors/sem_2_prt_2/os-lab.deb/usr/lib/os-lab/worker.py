#!/usr/bin/env python3
import ctypes
import sys
import time


def set_name(name: str) -> None:
    try:
        libc = ctypes.CDLL(None)
        libc.prctl(15, name.encode('utf-8')[:15], 0, 0, 0)
    except Exception:
        pass


def cpu(seconds: int) -> None:
    set_name('oslab-cpu')
    end = time.time() + max(1, seconds)
    value = 1
    while time.time() < end:
        value = (value * 33 + 17) % 10000019
    print(value)


def memory(mb: int, seconds: int) -> None:
    set_name('oslab-memory')
    size = max(1, mb) * 1024 * 1024
    data = bytearray(size)
    for index in range(0, size, 4096):
        data[index] = 1
    time.sleep(max(1, seconds))
    print(len(data))


def main() -> None:
    if len(sys.argv) < 3:
        raise SystemExit(2)
    if sys.argv[1] == 'cpu':
        cpu(int(sys.argv[2]))
    elif sys.argv[1] == 'memory':
        if len(sys.argv) < 4:
            raise SystemExit(2)
        memory(int(sys.argv[2]), int(sys.argv[3]))
    else:
        raise SystemExit(2)


if __name__ == '__main__':
    main()
