#!/usr/bin/env python3
import argparse
import configparser
import ctypes
import html
import logging
import subprocess
import sys
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

STATIC_DIR = Path('/usr/share/os-lab/static')
logger = logging.getLogger('os-lab')


def set_process_name(name: str) -> None:
    try:
        libc = ctypes.CDLL(None)
        libc.prctl(15, name.encode('utf-8')[:15], 0, 0, 0)
    except Exception:
        pass


def load_identity(path: str):
    values = {}
    with open(path, 'r', encoding='utf-8') as handle:
        for line in handle:
            line = line.strip()
            if line and '=' in line:
                key, value = line.split('=', 1)
                values[key] = value
    return values.get('LAB_ID', 'UNKNOWN'), values.get('LAB_IP', '127.0.0.1')


def load_config(path: str):
    cfg = configparser.ConfigParser()
    cfg.read(path, encoding='utf-8')
    port = cfg.getint('server', 'port', fallback=28080)
    log_file = cfg.get('logging', 'file', fallback='/var/log/os-lab/app.log')
    heartbeat = cfg.getint('logging', 'heartbeat_seconds', fallback=15)
    return port, log_file, max(5, heartbeat)


def setup_logging(log_file: str) -> None:
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
    stream = logging.StreamHandler(sys.stdout)
    stream.setFormatter(formatter)
    logger.addHandler(stream)
    try:
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    except OSError as exc:
        logger.error('ERROR log file unavailable: %s', exc)


def heartbeat(lab_id: str, lab_ip: str, interval: int) -> None:
    counter = 0
    while True:
        counter += 1
        level = logging.WARNING if counter % 4 == 0 else logging.INFO
        logger.log(level, 'Служебное событие: id=%s ip=%s seq=%s', lab_id, lab_ip, counter)
        time.sleep(interval)


def start_worker(mode: str, first: int, second: int = 0):
    command = ['/usr/bin/python3', '/usr/lib/os-lab/worker.py', mode, str(first)]
    if mode == 'memory':
        command.append(str(second))
    return subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


class Handler(BaseHTTPRequestHandler):
    server_version = 'os-lab/1.0'
    lab_id = 'UNKNOWN'
    lab_ip = '127.0.0.1'
    port = 28080

    def log_message(self, fmt, *args):
        logger.info('HTTP %s %s', self.address_string(), fmt % args)

    def send_bytes(self, code: int, body: bytes, content_type: str) -> None:
        self.send_response(code)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_text(self, code: int, text: str) -> None:
        self.send_bytes(code, text.encode('utf-8'), 'text/plain; charset=utf-8')

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        query = urllib.parse.parse_qs(parsed.query)

        if parsed.path == '/':
            event_code = f'E-{self.lab_id[-4:]}'
            logger.error('ERROR demo failure code=%s id=%s', event_code, self.lab_id)
            body = f'''<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<title>Лаборатория ОС</title>
<style>
body {{ margin:0; padding:28px; background:#f3f4f6; color:#202124; font-family:Arial,sans-serif; }}
main {{ max-width:1000px; margin:auto; background:white; padding:28px; border:1px solid #dedede; }}
h1 {{ margin-top:0; }}
.logos {{ display:flex; gap:30px; flex-wrap:wrap; align-items:center; }}
.logos img {{ max-width:430px; max-height:230px; object-fit:contain; border:1px solid #e2e2e2; background:white; }}
.error {{ margin-top:26px; padding:18px; border-left:6px solid #b42318; background:#fff1f0; color:#8a1111; font:700 20px monospace; }}
.info {{ margin-top:18px; line-height:1.6; }}
code {{ background:#f0f0f0; padding:2px 6px; }}
</style>
</head>
<body>
<main>
<h1>Лаборатория операционных систем</h1>
<div class="logos">
<img src="/static/nsu.png" alt="НГУ">
<img src="/static/fit.jpg" alt="ФИТ">
</div>
<div class="error">ERROR: demo failure code={html.escape(event_code)}</div>
<div class="info">
<p>Это учебная ошибка. Найдите ее в журнале сервиса.</p>
<p>ID: <strong>{html.escape(self.lab_id)}</strong></p>
<p>IP: <strong>{html.escape(self.lab_ip)}</strong></p>
<p>port: <strong>{self.port}</strong></p>
<p>Проверка: <code>journalctl -u os-lab | grep ERROR</code></p>
</div>
</main>
</body>
</html>'''
            self.send_bytes(200, body.encode('utf-8'), 'text/html; charset=utf-8')
            return

        if parsed.path == '/health':
            self.send_text(200, 'Сервис работает\n')
            return

        if parsed.path == '/error':
            logger.error('ERROR test endpoint requested id=%s', self.lab_id)
            self.send_text(500, 'ERROR: test endpoint\n')
            return

        if parsed.path == '/load/cpu':
            seconds = min(max(int(query.get('seconds', ['20'])[0]), 1), 120)
            proc = start_worker('cpu', seconds)
            logger.info('Запущена нагрузка CPU: pid=%s seconds=%s', proc.pid, seconds)
            self.send_text(200, f'Нагрузка CPU запущена. PID={proc.pid}, секунд={seconds}\n')
            return

        if parsed.path == '/load/memory':
            mb = min(max(int(query.get('mb', ['120'])[0]), 1), 512)
            seconds = min(max(int(query.get('seconds', ['20'])[0]), 1), 120)
            proc = start_worker('memory', mb, seconds)
            logger.info('Запущена нагрузка памяти: pid=%s mb=%s seconds=%s', proc.pid, mb, seconds)
            self.send_text(200, f'Нагрузка памяти запущена. PID={proc.pid}, МБ={mb}, секунд={seconds}\n')
            return

        if parsed.path == '/static/nsu.png':
            self.send_bytes(200, (STATIC_DIR / 'nsu.png').read_bytes(), 'image/png')
            return

        if parsed.path == '/static/fit.jpg':
            self.send_bytes(200, (STATIC_DIR / 'fit.jpg').read_bytes(), 'image/jpeg')
            return

        logger.warning('Неизвестный путь: %s', parsed.path)
        self.send_text(404, 'Страница не найдена\n')


def main() -> None:
    parser = argparse.ArgumentParser(description='Учебный сервис os-lab')
    parser.add_argument('--config', default='/etc/os-lab/config.ini')
    parser.add_argument('--identity', default='/etc/os-lab/identity.conf')
    args = parser.parse_args()

    set_process_name('os-lab')
    lab_id, lab_ip = load_identity(args.identity)
    port, log_file, heartbeat_seconds = load_config(args.config)
    setup_logging(log_file)
    Handler.lab_id = lab_id
    Handler.lab_ip = lab_ip
    Handler.port = port

    logger.info('Сервис запускается: id=%s ip=%s port=%s', lab_id, lab_ip, port)
    threading.Thread(target=heartbeat, args=(lab_id, lab_ip, heartbeat_seconds), daemon=True).start()
    server = ThreadingHTTPServer((lab_ip, port), Handler)
    logger.info('Сервис запущен: http://%s:%s/', lab_ip, port)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logger.info('Сервис остановлен вручную')
    finally:
        server.server_close()
        logger.info('Сервис завершил работу')


if __name__ == '__main__':
    main()
